CARA TES DAMARES GILA DARI ANDROID (WORKSPACE ONLINE)
=====================================================

Catatan: ini untuk uji coba sementara, bukan hosting produksi 24/7.

1. Buka https://replit.com/ di Chrome Android dan buat akun / login.
2. Cari menu untuk membuat/import project dari ZIP (Import from ZIP). Jika menu tidak muncul di HP,
   aktifkan "Situs desktop" dari menu Chrome.
3. Upload file DAMARES_GILA_ONLINE.zip.
4. Tunggu project terbuka. Tekan Run jika belum berjalan.
5. Buka tab Preview / Webview. Aplikasi memakai port 3000.

WAJIB SET SECRETS (ikon gembok / Tools > Secrets):
- SESSION_SECRET: isi string acak panjang minimal 32 karakter. Contoh format:
  damares-gila-test-2026-ubah-ini-1234567890-random
  Ganti contoh itu dengan nilai acak milikmu.
- ADMIN_USERNAME: admin
- ADMIN_PASSWORD: buat password admin pribadi minimal 12 karakter.
- NODE_ENV: development

Jangan taruh password admin di file atau chat. Masukkan langsung ke Secrets.
Untuk produksi, gunakan ADMIN_PASSWORD_HASH (bcrypt) dan NODE_ENV=production di server HTTPS.

TES:
A. Buka halaman utama dari Preview.
B. Daftar akun pemain pertama (misalnya pemain01) dengan password minimal 8 karakter.
C. Daftar akun kedua dengan username lain di tab browser/incognito atau browser lain.
D. Buka /admin pada URL Preview yang sama, login username admin dan password yang kamu simpan di Secrets.
E. Ubah harga market dari panel admin; cek apakah harga di dua akun pemain ikut berubah.
F. Uji BUY, SELL, tutup posisi, saldo dan riwayat.
G. Uji hadiah hanya untuk memastikan permintaan tercatat; jangan menjanjikan hadiah sampai aturan dan proses penukarannya siap.

PENTING:
- Workspace/preview dapat tidur atau berhenti; bukan jaminan website selalu online.
- Jangan gunakan data pribadi atau password yang dipakai di akun lain.
- Gunakan akun percobaan dan poin virtual saja.
- Harga adalah simulasi yang dikendalikan admin; bukan data harga pasar riil.
- Jangan mengaktifkan pembayaran/deposit.
- Bila Replit menolak native package better-sqlite3 atau import ZIP tidak tersedia di akun,
  kirim screenshot pesan error (tutup informasi pribadi/Secrets) agar bisa diperbaiki.
